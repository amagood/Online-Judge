from django.urls import path

from . import views

from django.http import HttpResponse

from django.http import HttpRequest

from .models import Question




def index(request):
    latest_question_list = Question.objects.order_by('-pub_date')[:5]
    output = ', '.join([q.question_text for q in latest_question_list])
    return HttpResponse(output)

app_name = 'polls'
urlpatterns = [
    # ex: /polls/
    path('', views.index, name='index'),
    # ex: /polls/5/
    path('<int:question_id>/', views.detail, name='detail'),
    # ex: /polls/5/results/
    path('<int:question_id>/results/', views.results, name='results'),
    # ex: /polls/5/vote/
    path('<int:question_id>/vote/', views.vote, name='vote'),
    #
    path('problem/p000/', views.get_code_string, name='p000'),
    #
    path('problem/p000/submit/', views.submit_status, name='submit')
]
