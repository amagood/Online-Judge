from django.http import Http404
from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from .models import Question
from django.http import JsonResponse
import os.path
import json


def results(request, question_id):
    response = "You're looking at the results of question %s."
    return HttpResponse(response % question_id)

def vote(request, question_id):
    return HttpResponse("You're voting on question %s." % question_id)


def index(request):
    latest_question_list = Question.objects.order_by('-pub_date')[:5]
    context = {'latest_question_list': latest_question_list}
    return render(request, 'polls/index.html', context)

def detail(request, question_id):
    try:
        question = Question.objects.get(pk=question_id)
    except Question.DoesNotExist:
        raise Http404("Question does not exist")
    return render(request, 'polls/detail.html', {'question': question})

def get_code_string(request):
    return render(request, 'polls/problem/p000.html', {})



def RunCode(id, language):
    os.system("sudo docker run -dit --rm -v /home/steven/" + id + ":/" + id + " --name " + id + " green2")
    #os.system("000")
    os.system("sudo docker exec " + id + " bash home/run.sh " + id + " " + language)
    os.system("sudo docker stop " + id )



def submit_status(request):

    write_file_from_request(request)

    RunCode("CodeRunner", "python")

    save_path = "/home/steven/CodeRunner/"
    file_name = "output.txt"
    real_file_name = os.path.join(save_path, file_name)

    fp = open(real_file_name,"r")
    output_message = fp.read()
    code_stats = ""
    exe_time = "0ms"
    if(output_message[0] == 'C' and output_message[1] == 'E'):
        code_stats = "CE"
        output_message = output_message.replace("CE", "" , 1)
        output_message = output_message.replace("File \"./CodeRunner/code.py\", ", "", 1)
    elif(output_message[0] == 'A' and output_message[1] == 'C'):
        code_stats = "AC"
        exe_time = "10ms"
    else:
        code_stats = "AC"
        exe_time = "10ms"


    data = {
        "codeStats":code_stats,
        "errorMessage":output_message,
        "exeTime":exe_time,
        "errorOutputCompare":"size",
        "wrongOutput":"your output",
        "hash":"A7FCFC6B5269BDCCE571798D618EA219A68B96CB87A0E21080C2E758D23E4CE9"
    }
    return JsonResponse(data)



def write_file_from_request(request):
    if request.method == "POST":
        code_json = request.body
        code_json = str(code_json , encoding = "utf-8")

        test_json = json.loads(request.body)
        print(test_json['language'])
        print(test_json['file']['file1'])

        save_path = "/home/steven/CodeRunner/"
        if(str(test_json['language']) == 'python'):
            tmp_file_name = 'py'
        else:
            tmp_file_name = str(test_json['language'])
        file_name = "code." + tmp_file_name  # + str(file_num) + ".py"
        real_file_name = os.path.join(save_path, file_name)
        fp = open(real_file_name, "w")
        print(test_json['file']['file1'], file= fp)
        fp.close()




# Create your views here.
