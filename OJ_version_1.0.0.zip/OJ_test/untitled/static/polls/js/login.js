
var app1 = new Vue({
  el: "#app1",
  data: {
    showFocus1: false,
    showFocus2: false
  }
})