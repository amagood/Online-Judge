import os

def RunCode(id, language):
    os.system("sudo docker run -dit --rm -v /home/steven/" + id + ":/" + id + " --name " + id + " green2")
    #os.system("000")
    os.system("sudo docker exec " + id + " bash home/run.sh " + id + " " + language)
    os.system("sudo docker stop " + id )
    return 0

RunCode("CodeRunner","python")
