#!/bin/bash

id=$1
language=$2

# check if executor exist
if ! test -f executor; then

	# check if executor.c exist
	if test -f executor.c; then
		gcc -o executor executor.c
	else
		echo "no executor"
		exit 1
	fi
fi

if [ "${language}" == "c" ]; then
	error=$(make -C ${id}/ 2>&1)
	
	# check if compile error
	if [ "$?" == "2" ]; then
		printf "@@CE@@\n" > ./${id}/output.txt
		printf "${error}" >> ./${id}/output.txt
		exit 0
	fi
	
	./executor ${id} ${language} > ./${id}/mem_output.txt
	status=$?
	if [ "${status}" == "1" ]; then
		echo "something wrong in executor"
		exit 1
	fi
	
elif [ "${language}" == "c++" ]; then
	error=$(make -C ${id}/ 2>&1)
	
	# check if compile error
	if [ "$?" == "2" ]; then
		printf "@@CE@@\n" > ./${id}/output.txt
		printf "${error}" >> ./${id}/output.txt
		exit 0
	fi
	
	./executor ${id} ${language} > ./${id}/mem_output.txt
	status=$?
	if [ "${status}" == "1" ]; then
		echo "something wrong in executor"
		exit 1		
	fi
	
elif [ "${language}" == "python" ]; then
	./executor ${id} ${language} > ./${id}/mem_output.txt
	status=$?
	if [ "${status}" == "1" ]; then
		echo "somethine wrong in executor"
		exit 1
	fi
fi

exit 0
