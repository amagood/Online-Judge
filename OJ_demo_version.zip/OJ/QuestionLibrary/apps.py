from django.apps import AppConfig


class QuestionlibraryConfig(AppConfig):
    name = 'QuestionLibrary'
