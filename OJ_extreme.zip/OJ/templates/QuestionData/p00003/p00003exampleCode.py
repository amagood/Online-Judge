a=[int(e) for e in input().split()]
print(sum(a))
