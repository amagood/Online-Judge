from django.shortcuts import render
from django.http import JsonResponse
import os.path
import json




def get_code_string(request):
    return render(request, 'IDE/problem/p000.html', {})



def RunCode(id, language):
    os.system("sudo docker run -dit --rm -v /home/steven/" + id + ":/" + id + " --name " + id + " green_image")
    os.system("sudo docker exec " + id + " bash home/run.sh " + id + " " + language)
    os.system("sudo docker stop " + id )




def submit_status(request):

    write_file_from_request(request)

    code_json = request.body
    code_json = str(code_json, encoding="utf-8")
    test_json = json.loads(request.body)

    RunCode("CodeRunner", str(test_json['language']))
    print(str(test_json['language']))
    save_path = "/home/steven/CodeRunner"
    file_name = "output.txt"
    real_file_name = os.path.join(save_path, file_name)

    fp = open(real_file_name,"r")
    output_message = fp.read()
    code_stats = ""
    exe_time = "0ms"

    answer = open("/home/steven/CodeRunner/answer.txt", "r")
    answer_str = answer.read()

    if(output_message[0] == 'C' and output_message[1] == 'E'):
        code_stats = "CE"
        output_message = output_message.replace("CE", "" , 1)
        output_message = output_message.replace("File \"./CodeRunner/code.py\", ", "", 1)
    elif (answer_str == output_message):
        code_stats = "AC"
        exe_time = "10ms"
    else:
        code_stats = "WA"
        exe_time = "Runtime:10ms | Your Output is:" + str(output_message) + " | Right Output is:" + str(answer_str)


    data = {
        "codeStats":code_stats,
        "errorMessage":output_message,
        "exeTime":exe_time,
        "errorOutputCompare":"size",
        "wrongOutput":"your output",
        "hash":"A7FCFC6B5269BDCCE571798D618EA219A68B96CB87A0E21080C2E758D23E4CE9"
    }
    return JsonResponse(data)



def write_file_from_request(request):
    if request.method == "POST":
        code_json = request.body
        code_json = str(code_json , encoding = "utf-8")

        test_json = json.loads(request.body)
        print(test_json['language'])
        print(test_json['file']['file1'])

        save_path = "/home/steven/CodeRunner"
        if(str(test_json['language']) == 'python'):
            tmp_file_name = 'py'
        else:
            tmp_file_name = str(test_json['language'])
        file_name = "code." + tmp_file_name  # + str(file_num) + ".py"
        real_file_name = os.path.join(save_path, file_name)
        fp = open(real_file_name, "w")
        print(test_json['file']['file1'], file= fp)
        fp.close()




# Create your views here.
