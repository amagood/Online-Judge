### 2019/11/25 Validation Message
	html js add login message and spinner
### 2019/11/25 Validation and Naming
	html js
	revise validate functions and improve readability
	postURL = ""
	change path of external js in login.html
### 2019/11/24 Validation
	html css js change color to red when value is invalid
### 2019/11/22 Redirect
	js store data and redirct after login
### 2019/11/18 load static
	html {% load static %}
### 2019/11/18 Server-Specific File 
	html
### 2019/11/18/ Post
	html js
	post when click login button, and show detail in console
### 2019/11/16 Validation
	maxlength=20
	pattern=[A-Za-z0-9].{6,}
	show content after onload
### 2019/11/15 Login First Commit
	login.html css js